﻿#include <stdio.h>

int main(){
	printf("Hello 120L022115-王炳轩");
	return 0;
}
